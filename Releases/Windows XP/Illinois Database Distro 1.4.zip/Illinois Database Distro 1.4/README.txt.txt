If you have previously installed version 1.2 or newer on your machine, you may skip step 1.  If you have any version of
this program installed, you should uninstall it through the Control Panel before continuing.

If installing for the first time, Doubleclick the INSTALL.bat file.

If reinstalling, doubleclick setup.exe